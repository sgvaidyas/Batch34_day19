﻿namespace batch34_day19
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblname = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.lblcourse = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.rdgendermale = new System.Windows.Forms.RadioButton();
            this.rdgenderfemale = new System.Windows.Forms.RadioButton();
            this.rdgenderothers = new System.Windows.Forms.RadioButton();
            this.datedob = new System.Windows.Forms.DateTimePicker();
            this.cbcourse = new System.Windows.Forms.ComboBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(36, 48);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(67, 13);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "FULL NAME";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Location = new System.Drawing.Point(36, 97);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(42, 13);
            this.lblemail.TabIndex = 1;
            this.lblemail.Text = "EMAIL ";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(36, 146);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(53, 13);
            this.lblgender.TabIndex = 2;
            this.lblgender.Text = "GENDER";
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.Location = new System.Drawing.Point(36, 196);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(89, 13);
            this.lbldob.TabIndex = 3;
            this.lbldob.Text = "DATE OF BIRTH";
            // 
            // lblcourse
            // 
            this.lblcourse.AutoSize = true;
            this.lblcourse.Location = new System.Drawing.Point(37, 249);
            this.lblcourse.Name = "lblcourse";
            this.lblcourse.Size = new System.Drawing.Size(52, 13);
            this.lblcourse.TabIndex = 4;
            this.lblcourse.Text = "COURSE";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(199, 40);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(219, 20);
            this.txtname.TabIndex = 5;
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(199, 89);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(219, 20);
            this.txtemail.TabIndex = 6;
            // 
            // rdgendermale
            // 
            this.rdgendermale.AutoSize = true;
            this.rdgendermale.Location = new System.Drawing.Point(199, 141);
            this.rdgendermale.Name = "rdgendermale";
            this.rdgendermale.Size = new System.Drawing.Size(54, 17);
            this.rdgendermale.TabIndex = 7;
            this.rdgendermale.TabStop = true;
            this.rdgendermale.Text = "MALE";
            this.rdgendermale.UseVisualStyleBackColor = true;
            // 
            // rdgenderfemale
            // 
            this.rdgenderfemale.AutoSize = true;
            this.rdgenderfemale.Location = new System.Drawing.Point(277, 141);
            this.rdgenderfemale.Name = "rdgenderfemale";
            this.rdgenderfemale.Size = new System.Drawing.Size(67, 17);
            this.rdgenderfemale.TabIndex = 8;
            this.rdgenderfemale.TabStop = true;
            this.rdgenderfemale.Text = "FEMALE";
            this.rdgenderfemale.UseVisualStyleBackColor = true;
            // 
            // rdgenderothers
            // 
            this.rdgenderothers.AutoSize = true;
            this.rdgenderothers.Location = new System.Drawing.Point(367, 141);
            this.rdgenderothers.Name = "rdgenderothers";
            this.rdgenderothers.Size = new System.Drawing.Size(70, 17);
            this.rdgenderothers.TabIndex = 9;
            this.rdgenderothers.TabStop = true;
            this.rdgenderothers.Text = "OTHERS";
            this.rdgenderothers.UseVisualStyleBackColor = true;
            // 
            // datedob
            // 
            this.datedob.Location = new System.Drawing.Point(199, 188);
            this.datedob.Name = "datedob";
            this.datedob.Size = new System.Drawing.Size(219, 20);
            this.datedob.TabIndex = 10;
            // 
            // cbcourse
            // 
            this.cbcourse.FormattingEnabled = true;
            this.cbcourse.Items.AddRange(new object[] {
            "BE",
            "MTECH",
            "BTECH",
            "BCA",
            "MCA",
            "BSC",
            "MSC",
            "BCOM",
            "MCOM"});
            this.cbcourse.Location = new System.Drawing.Point(199, 240);
            this.cbcourse.Name = "cbcourse";
            this.cbcourse.Size = new System.Drawing.Size(219, 21);
            this.cbcourse.TabIndex = 11;
            // 
            // btnsubmit
            // 
            this.btnsubmit.Location = new System.Drawing.Point(199, 299);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 12;
            this.btnsubmit.Text = "SUBMIT";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.cbcourse);
            this.Controls.Add(this.datedob);
            this.Controls.Add(this.rdgenderothers);
            this.Controls.Add(this.rdgenderfemale);
            this.Controls.Add(this.rdgendermale);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblcourse);
            this.Controls.Add(this.lbldob);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.lblemail);
            this.Controls.Add(this.lblname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Label lblcourse;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.RadioButton rdgendermale;
        private System.Windows.Forms.RadioButton rdgenderfemale;
        private System.Windows.Forms.RadioButton rdgenderothers;
        private System.Windows.Forms.DateTimePicker datedob;
        private System.Windows.Forms.ComboBox cbcourse;
        private System.Windows.Forms.Button btnsubmit;
    }
}

