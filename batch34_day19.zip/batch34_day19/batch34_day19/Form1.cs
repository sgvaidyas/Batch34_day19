﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace batch34_day19
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string name, email, gender, dob, course,test;

            name = txtname.Text;
            email = txtemail.Text;

            if (rdgendermale.Checked)
                gender = "Male";
            else if (rdgenderfemale.Checked)
                gender = "Female";
            else
                gender = "Others";

            dob = datedob.Value.ToString();


            course = cbcourse.SelectedItem.ToString();

            test = name + "\n" + email + "\n" + gender+"\n"+dob+"\n"+course;
            MessageBox.Show(test);
        }
    }
}
