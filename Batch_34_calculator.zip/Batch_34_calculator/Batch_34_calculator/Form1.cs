﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Batch_34_calculator
{
    public partial class Form1 : Form
    {
        string num;
        float prevnum;
        public Form1()
        {
            InitializeComponent();
            num = "";
            prevnum = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void btndigits_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            num += b.Text;
            txtdisplay.Text = num;
        }

        private void btnbackspace_Click(object sender, EventArgs e)
        {
            int noofchar = num.Length;
            if (noofchar > 0)
                num = num.Remove(noofchar - 1, 1);
            else
                num = "";
            txtdisplay.Text = num;
        }
        private void btnce_Click(object sender, EventArgs e)
        {
            num = "";
            txtdisplay.Text = num;
        }
        private void btnc_Click(object sender, EventArgs e)
        {
            num = "";
            txtdisplay.Text = num;
        }



        private void btnequal_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            var res = dt.Compute(num, "");
           // MessageBox.Show(res.ToString());
            num = res.ToString();
            txtdisplay.Text = num;
        }
    }
}
